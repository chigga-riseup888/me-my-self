# MiFi 动态库依赖分析工具 ABCD V1.0

本工具包与《MiFi动态库依赖与裁剪分析工具使用 SOP V1.0》一一对应。

| SOP 简称 | 文件名 | 版本基线 | 作用 |
|---|---|---|---|
| Script A | `analyze.py` | 修正版 | 静态 ELF `DT_NEEDED`、动态强符号关系、库可达性、循环依赖及冗余链接候选分析。 |
| Script B | `scan_dlopen_plugin_evidence.py` | v2 | 扫描 A 无法覆盖的有效 `dlopen/dlmopen` 字符串、配置引用和插件目录线索；过滤自身 SONAME、已有 `DT_NEEDED` 和构建元数据噪声。 |
| Script C | `collect_runtime_dependencies.sh` | 当前版 | 样机持续采集 `/proc/<pid>/maps`、进程信息和进程—动态库关系；支持 Ctrl+C 安全收尾。 |
| Script D | `merge_dependency_evidence.py` | v2 | 合并 A/B/C，读取 `process_library_edges.tsv` 并在 `runtime_evidence` 中记录具体加载进程。 |

## 标准执行顺序

```bash
ROOTFS=/absolute/path/to/filesystem

python3 analyze.py "$ROOTFS" \
  --verbose \
  --json-report dependency_report.json \
  2>&1 | tee dependency_output.txt

python3 scan_dlopen_plugin_evidence.py "$ROOTFS" \
  --json-report plugin_evidence_v2.json \
  --text-report plugin_evidence_v2.txt

# 在样机执行
sh collect_runtime_dependencies.sh \
  --scenario normal_mifi_usage \
  --interval 2 \
  --duration 300

# 在 PC 执行；runtime-dir 必须是直接包含 meta.txt、loaded_libraries.txt、
# process_library_edges.tsv 的具体场景目录
python3 merge_dependency_evidence.py "$ROOTFS" \
  --static-json dependency_report.json \
  --plugin-json plugin_evidence_v2.json \
  --runtime-dir runtime_sessions/normal_mifi_usage_YYYYMMDD_HHMMSS_PID \
  --output-prefix final_lib_report_v2
```

## 依赖

- PC：Python 3.6+、`readelf`、`file`
- 样机：POSIX `sh`、已挂载的 `/proc`
- Script C 建议以 root 权限运行，以减少 `/proc/<pid>` 读取失败

## 版本确认

`CHECKSUMS.sha256` 保存本包四个脚本及本说明文件的 SHA-256。归档、评审和问题复现时，应同时记录该文件。

> 本包仅包含 SOP 定义的 A/B/C/D 四个脚本。`trace_process_dlopen.sh` 属于专项补充工具，不属于 SOP V1.0 的标准四脚本，因此未放入本包。
