# 动态库依赖分析脚本 v2 更新说明

本压缩包包含两个需要替换的脚本：

- `scan_dlopen_plugin_evidence.py`：脚本 B，重新生成动态加载和插件线索；
- `merge_dependency_evidence.py`：合并脚本，重新生成最终 JSON/CSV/TXT。

脚本 A 的 `dependency_report.json` 和已经采集好的 `runtime_sessions` **可以继续使用，不需要重新采集样机**。

---

## 一、本次修复内容

### 脚本 B

旧版会把 ELF 中所有形似 `libxxx.so` 的字符串都当作 `dynamic-hint`，因此可能出现：

```text
mod_openssl.so -> dynamic-hint:elf-string:/lib/mod_openssl.so
```

这通常只是库自己的文件名或 `DT_SONAME`，不是 `dlopen()` 加载自己。

新版过滤：

1. 当前 ELF 自身文件名和 `DT_SONAME`；
2. 已经存在于该 ELF `DT_NEEDED` 中的普通静态依赖；
3. ELF 没有导入 `dlopen/dlmopen` 时出现的孤立 `.so` 字符串；
4. ELF `PT_INTERP` 中的动态加载器字符串；
5. `.la`、`.pc` 等编译链接元数据文件。

新版只有满足下面条件的 ELF 字符串才进入最终动态线索：

```text
来源 ELF 导入 dlopen/dlmopen
+ 字符串指向另一个共享库
+ 不是来源 ELF 自身 SONAME
+ 不在来源 ELF 的 DT_NEEDED 中
```

有效线索格式改为：

```text
dynamic-hint:elf-dlopen-string:/来源程序路径
```

### 合并脚本

新版会读取：

```text
process_library_edges.tsv
```

因此 `runtime_evidence` 不再只有场景名称，而会写明具体进程：

```text
runtime:normal_mifi_usage:process:/bin/mobile
runtime:normal_mifi_usage:process:/usr/sbin/uhttpd
```

同时对旧版 `plugin_evidence.json` 也增加了部分防御性过滤，但为了得到最干净的结果，仍建议使用新版脚本 B 重新生成 `plugin_evidence.json`。

---

## 二、重新生成动态加载线索

```bash
python3 scan_dlopen_plugin_evidence.py \
    /home/bba/work/bba/7350_develop/platform/targets/M7350/EU/filesystem \
    --json-report plugin_evidence_v2.json \
    --text-report plugin_evidence_v2.txt
```

运行结束时会打印过滤统计，例如：

```text
有效动态线索: xx
过滤自身 SONAME/文件名: xx
过滤 DT_NEEDED 重复字符串: xx
```

---

## 三、重新生成最终报告

`--runtime-dir` 必须指向直接包含以下文件的实际采集目录：

```text
loaded_libraries.txt
process_library_edges.tsv
meta.txt
```

执行示例：

```bash
python3 merge_dependency_evidence.py \
    /home/bba/work/bba/7350_develop/platform/targets/M7350/EU/filesystem \
    --static-json dependency_report.json \
    --plugin-json plugin_evidence_v2.json \
    --runtime-dir runtime_sessions/normal_mifi_usage_实际目录 \
    --output-prefix final_lib_report_v2
```

输出：

```text
final_lib_report_v2.json
final_lib_report_v2.csv
final_lib_report_v2.txt
```

---

## 四、哪些数据需要重新生成

| 数据 | 是否需要重新生成 |
|---|---|
| `dependency_report.json` | 不需要 |
| `repory.txt` | 不需要 |
| `runtime_sessions/` | 不需要 |
| `plugin_evidence.json` | 需要，用新版脚本 B 重新生成 |
| `plugin_evidence.txt` | 需要 |
| `final_lib_report.json/csv/txt` | 需要，用新版合并脚本重新生成 |

---

## 五、结果检查

### 检查自身引用是否消失

```bash
grep -n 'elf-dlopen-string:/lib/mod_openssl.so' plugin_evidence_v2.txt
```

如果 `mod_openssl.so` 只是自身 SONAME，该命令应没有结果。

### 检查运行进程信息

在最终 CSV 的 `runtime_evidence` 列应看到：

```text
runtime:normal_mifi_usage:process:/具体进程路径
```

而不再只是：

```text
runtime:normal_mifi_usage
```
