#!/usr/bin/env python3
"""
产物侧 dlopen / 插件 / 配置引用线索扫描器（v2）。

本版本重点降低误报：
1. 过滤共享库自身 SONAME/文件名造成的“自己引用自己”；
2. 过滤已经出现在 ELF DT_NEEDED 中的普通静态依赖字符串；
3. 只有 ELF 确实导入 dlopen/dlmopen 时，额外 .so 字符串才作为动态加载线索；
4. 过滤 .la/.pc 等构建元数据文件，避免被误认为运行时配置；
5. 保留被过滤项的统计和明细，便于审计。

用法：
    python3 scan_dlopen_plugin_evidence.py <rootfs> \
        --json-report plugin_evidence.json \
        --text-report plugin_evidence.txt
"""

import argparse
import json
import os
import re
import subprocess
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple

DYNAMIC_LOADER_SYMBOLS = {
    "dlopen",
    "dlmopen",
    "dlsym",
    "dlvsym",
    "dlclose",
}

# 只有这两个接口能直接证明 ELF 具备“加载另一个共享库”的能力。
DYNAMIC_LIBRARY_OPEN_SYMBOLS = {"dlopen", "dlmopen"}

PLUGIN_KEYWORDS = re.compile(
    r"(?i)\b(plugin|plugins|module|modules|loadmodule|load_module|"
    r"dynamic_module|extension|extensions|driver|backend|provider|engine)\b"
)

SO_PATTERN = re.compile(
    rb"(?:(?:/[-A-Za-z0-9_+.@]+)+/)?"
    rb"(?:lib|mod_)?[-A-Za-z0-9_+.@]+\.so(?:\.[-A-Za-z0-9_+.@]+)*"
)

TEXT_SO_PATTERN = re.compile(
    r"(?:(?:/[-A-Za-z0-9_+.@]+)+/)?"
    r"(?:lib|mod_)?[-A-Za-z0-9_+.@]+\.so(?:\.[-A-Za-z0-9_+.@]+)*"
)

PLUGIN_DIR_NAMES = {
    "plugin",
    "plugins",
    "module",
    "modules",
    "extensions",
    "providers",
    "engines",
}

TEXT_EXTENSIONS = {
    ".conf", ".cfg", ".ini", ".json", ".xml", ".yaml", ".yml",
    ".service", ".sh", ".rc", ".lua", ".py", ".js", ".uci",
}

# 这些文件通常是编译/链接元数据，不应作为样机运行时插件配置证据。
IGNORED_METADATA_SUFFIXES = {".la", ".pc"}


def is_elf(path: Path) -> bool:
    try:
        with path.open("rb") as file_obj:
            return file_obj.read(4) == b"\x7fELF"
    except OSError:
        return False


def is_probably_text(path: Path) -> bool:
    if path.suffix.lower() in TEXT_EXTENSIONS:
        return True
    try:
        data = path.read_bytes()[:4096]
    except OSError:
        return False
    if not data:
        return True
    if b"\x00" in data:
        return False
    printable = sum(1 for byte in data if byte in b"\t\n\r" or 32 <= byte < 127)
    return printable / len(data) >= 0.85


def run_readelf(args: List[str], path: Path) -> str:
    """执行 readelf；即使返回码非零，也保留 stdout 中的有效结果。"""
    try:
        result = subprocess.run(
            ["readelf"] + list(args) + [str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=20,
            check=False,
        )
        return result.stdout or ""
    except (OSError, subprocess.SubprocessError):
        return ""


def dynamic_undefined_names(path: Path) -> Set[str]:
    output = run_readelf(["-W", "-s", "-D"], path)
    names: Set[str] = set()
    for line in output.splitlines():
        match = re.match(
            r"^\s*\d+:\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+UND\s+(\S+)",
            line,
        )
        if not match:
            continue
        names.add(match.group(1).split("@", 1)[0])
    return names


def dynamic_tags(path: Path) -> Tuple[Set[str], Optional[str]]:
    """解析 DT_NEEDED 和 DT_SONAME。"""
    output = run_readelf(["-W", "-d"], path)
    needed: Set[str] = set()
    soname: Optional[str] = None

    for line in output.splitlines():
        needed_match = re.search(r"\(NEEDED\).*?\[(.+?)\]", line)
        if needed_match:
            needed.add(needed_match.group(1))
            continue

        soname_match = re.search(r"\(SONAME\).*?\[(.+?)\]", line)
        if soname_match:
            soname = soname_match.group(1)

    return needed, soname


def program_interpreter(path: Path) -> Optional[str]:
    """解析 ELF PT_INTERP 指定的动态加载器路径。"""
    output = run_readelf(["-W", "-l"], path)
    for line in output.splitlines():
        match = re.search(r"Requesting program interpreter:\s*([^\]]+)", line)
        if match:
            return match.group(1).strip()
    return None


def printable_strings(data: bytes, min_len: int = 4) -> Iterable[bytes]:
    current = bytearray()
    for value in data:
        if 32 <= value < 127:
            current.append(value)
        else:
            if len(current) >= min_len:
                yield bytes(current)
            current.clear()
    if len(current) >= min_len:
        yield bytes(current)


def embedded_so_references(path: Path) -> Set[str]:
    refs: Set[str] = set()
    try:
        data = path.read_bytes()
    except OSError:
        return refs

    for raw_string in printable_strings(data):
        for match in SO_PATTERN.finditer(raw_string):
            refs.add(match.group(0).decode("utf-8", errors="replace"))
    return refs


def text_evidence(path: Path) -> Tuple[Set[str], List[str]]:
    so_refs: Set[str] = set()
    keyword_lines: List[str] = []

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return so_refs, keyword_lines

    for line_number, line in enumerate(text.splitlines(), 1):
        found_sos = TEXT_SO_PATTERN.findall(line)
        for ref in found_sos:
            so_refs.add(ref)

        if found_sos or PLUGIN_KEYWORDS.search(line):
            compact = " ".join(line.strip().split())
            if compact:
                keyword_lines.append("{}: {}".format(line_number, compact[:500]))

    return so_refs, keyword_lines[:200]


def relpath(path: Path, root: Path) -> str:
    try:
        return "/" + str(path.relative_to(root))
    except ValueError:
        return str(path)


def is_shared_library_filename(name: str) -> bool:
    return name.endswith(".so") or ".so." in name


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("rootfs")
    parser.add_argument("--json-report", default="plugin_evidence.json")
    parser.add_argument("--text-report", default="plugin_evidence.txt")
    args = parser.parse_args()

    root = Path(args.rootfs).resolve()
    if not root.is_dir():
        raise SystemExit("rootfs 不存在: {}".format(root))

    elf_records: List[dict] = []
    text_records: List[dict] = []
    plugin_directories: Dict[str, List[str]] = {}
    library_referrers: Dict[str, Set[str]] = defaultdict(set)
    all_shared_libraries: List[str] = []

    ignored_metadata_files: List[str] = []
    ignored_self_reference_count = 0
    ignored_needed_reference_count = 0
    ignored_without_dlopen_reference_count = 0
    ignored_interpreter_reference_count = 0
    valid_elf_dynamic_reference_count = 0

    for current_root, dirs, files in os.walk(root):
        current = Path(current_root)

        for dirname in dirs:
            if dirname.lower() in PLUGIN_DIR_NAMES:
                plugin_dir = current / dirname
                members: List[str] = []
                try:
                    for member in sorted(plugin_dir.iterdir()):
                        if member.is_file() or member.is_symlink():
                            if is_shared_library_filename(member.name):
                                members.append(relpath(member, root))
                except OSError:
                    pass
                plugin_directories[relpath(plugin_dir, root)] = members

        for filename in files:
            path = current / filename
            virtual_path = relpath(path, root)

            if is_shared_library_filename(filename) and (path.is_file() or path.is_symlink()):
                all_shared_libraries.append(virtual_path)

            # 符号链接由真实文件统一分析，避免重复扫描。
            if path.is_symlink():
                continue

            if is_elf(path):
                undefined = dynamic_undefined_names(path)
                loader_symbols = sorted(undefined & DYNAMIC_LOADER_SYMBOLS)
                can_open_library = bool(undefined & DYNAMIC_LIBRARY_OPEN_SYMBOLS)
                needed_libraries, soname = dynamic_tags(path)
                interpreter = program_interpreter(path)
                interpreter_name = os.path.basename(interpreter) if interpreter else None
                embedded_refs = sorted(embedded_so_references(path))

                self_names = {path.name}
                if soname:
                    self_names.add(soname)

                valid_dynamic_refs: List[str] = []
                ignored_self_refs: List[str] = []
                ignored_needed_refs: List[str] = []
                ignored_without_dlopen_refs: List[str] = []
                ignored_interpreter_refs: List[str] = []

                for ref in embedded_refs:
                    ref_name = os.path.basename(ref)

                    # 过滤当前库自己的真实文件名或 SONAME。
                    if ref_name in self_names:
                        ignored_self_refs.append(ref)
                        ignored_self_reference_count += 1
                        continue

                    # 过滤 PT_INTERP 指定的动态加载器字符串。
                    if interpreter_name and ref_name == interpreter_name:
                        ignored_interpreter_refs.append(ref)
                        ignored_interpreter_reference_count += 1
                        continue

                    # 过滤 DT_NEEDED 已声明的普通静态依赖。
                    if ref_name in needed_libraries:
                        ignored_needed_refs.append(ref)
                        ignored_needed_reference_count += 1
                        continue

                    # 没有 dlopen/dlmopen，孤立 .so 字符串不作为动态加载候选。
                    if not can_open_library:
                        ignored_without_dlopen_refs.append(ref)
                        ignored_without_dlopen_reference_count += 1
                        continue

                    valid_dynamic_refs.append(ref)
                    valid_elf_dynamic_reference_count += 1
                    library_referrers[ref_name].add(
                        "elf-dlopen-string:{}".format(virtual_path)
                    )

                if (
                    loader_symbols
                    or valid_dynamic_refs
                    or ignored_self_refs
                    or ignored_needed_refs
                    or ignored_without_dlopen_refs
                    or ignored_interpreter_refs
                ):
                    elf_records.append({
                        "path": virtual_path,
                        "dynamic_loader_symbols": loader_symbols,
                        "can_open_shared_library": can_open_library,
                        "soname": soname,
                        "needed_libraries": sorted(needed_libraries),
                        "program_interpreter": interpreter,
                        "valid_dynamic_shared_library_references": sorted(valid_dynamic_refs),
                        "ignored_self_references": sorted(ignored_self_refs),
                        "ignored_needed_references": sorted(ignored_needed_refs),
                        "ignored_without_dlopen_references": sorted(
                            ignored_without_dlopen_refs
                        ),
                        "ignored_interpreter_references": sorted(
                            ignored_interpreter_refs
                        ),
                    })
                continue

            # 过滤 libtool/pkg-config 构建元数据，防止 .la/.pc 中的库名误报。
            if path.suffix.lower() in IGNORED_METADATA_SUFFIXES:
                ignored_metadata_files.append(virtual_path)
                continue

            if is_probably_text(path):
                so_refs, evidence_lines = text_evidence(path)
                if so_refs or evidence_lines:
                    text_records.append({
                        "path": virtual_path,
                        "shared_library_references": sorted(so_refs),
                        "evidence_lines": evidence_lines,
                    })
                for ref in so_refs:
                    library_referrers[os.path.basename(ref)].add(
                        "text-config:{}".format(virtual_path)
                    )

    # 位于明确插件目录中的共享库，保留为插件候选证据。
    for directory, members in plugin_directories.items():
        for member in members:
            library_referrers[os.path.basename(member)].add(
                "plugin-directory:{}".format(directory)
            )

    report = {
        "schema_version": 2,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "rootfs": str(root),
        "filter_policy": {
            "self_soname_reference_ignored": True,
            "dt_needed_string_reference_ignored": True,
            "elf_string_requires_dlopen_or_dlmopen": True,
            "ignored_metadata_suffixes": sorted(IGNORED_METADATA_SUFFIXES),
        },
        "elf_record_count": len(elf_records),
        "valid_elf_dynamic_reference_count": valid_elf_dynamic_reference_count,
        "ignored_self_reference_count": ignored_self_reference_count,
        "ignored_needed_reference_count": ignored_needed_reference_count,
        "ignored_without_dlopen_reference_count": (
            ignored_without_dlopen_reference_count
        ),
        "ignored_interpreter_reference_count": ignored_interpreter_reference_count,
        "ignored_metadata_file_count": len(ignored_metadata_files),
        "text_files_with_plugin_evidence_count": len(text_records),
        "plugin_directory_count": len(plugin_directories),
        "shared_library_file_count": len(set(all_shared_libraries)),
        "elf_records": sorted(elf_records, key=lambda item: item["path"]),
        "text_records": sorted(text_records, key=lambda item: item["path"]),
        "plugin_directories": dict(sorted(plugin_directories.items())),
        "ignored_metadata_files": sorted(ignored_metadata_files),
        "library_referrers": {
            name: sorted(refs)
            for name, refs in sorted(library_referrers.items())
        },
        "all_shared_libraries": sorted(set(all_shared_libraries)),
    }

    json_path = Path(args.json_report)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    lines = [
        "=" * 80,
        "dlopen / 插件 / 配置引用线索报告（已过滤自身 SONAME/DT_NEEDED 噪声）",
        "=" * 80,
        "rootfs: {}".format(root),
        "有效 ELF 动态库字符串线索: {}".format(
            valid_elf_dynamic_reference_count
        ),
        "过滤自身文件名/SONAME: {}".format(ignored_self_reference_count),
        "过滤已存在于 DT_NEEDED 的字符串: {}".format(
            ignored_needed_reference_count
        ),
        "过滤无 dlopen/dlmopen 的孤立 .so 字符串: {}".format(
            ignored_without_dlopen_reference_count
        ),
        "过滤 PT_INTERP 动态加载器字符串: {}".format(
            ignored_interpreter_reference_count
        ),
        "过滤 .la/.pc 元数据文件: {}".format(len(ignored_metadata_files)),
        "含插件/共享库线索的文本文件: {}".format(len(text_records)),
        "插件目录: {}".format(len(plugin_directories)),
        "共享库文件: {}".format(len(set(all_shared_libraries))),
        "",
        "按库汇总的有效动态引用线索:",
    ]

    if library_referrers:
        for name, refs in sorted(library_referrers.items()):
            lines.append("\n{}".format(name))
            for ref in sorted(refs):
                lines.append("  - {}".format(ref))
    else:
        lines.append("  无")

    lines.extend([
        "",
        "说明:",
        "1. elf-dlopen-string 表示来源 ELF 导入了 dlopen/dlmopen，且该库名不是自身 SONAME，也不在 DT_NEEDED 中。",
        "2. text-config 表示运行时配置或脚本中出现该共享库名称。",
        "3. plugin-directory 表示该库位于明确的插件/模块目录。",
        "4. 以上仍是动态加载线索，不等同于样机运行时已经加载；需结合 /proc/<pid>/maps 或 strace。",
        "5. 未发现线索也不能直接证明可删除，仍可能存在运行时拼接库名、远端配置或未覆盖条件路径。",
    ])

    text_path = Path(args.text_report)
    text_path.parent.mkdir(parents=True, exist_ok=True)
    text_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("JSON 报告: {}".format(json_path.resolve()))
    print("文本报告: {}".format(text_path.resolve()))
    print("有效动态线索: {}".format(valid_elf_dynamic_reference_count))
    print("过滤自身 SONAME/文件名: {}".format(ignored_self_reference_count))
    print("过滤 DT_NEEDED 重复字符串: {}".format(
        ignored_needed_reference_count
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
