# MiFi 动态库运行时依赖闭环工具

这套工具补齐静态 ELF 分析无法发现的三类依赖：

1. `dlopen()` / `dlsym()` 延迟加载；
2. 插件目录、配置文件、脚本指定的模块；
3. 只有在 VPN、FOTA、USB、恢复、异常处理等条件功能中才加载的库。

## 文件

- `collect_runtime_dependencies.sh`
  - 放到样机执行。
  - 周期读取 `/proc/<pid>/maps`，记录进程实际映射的动态库。
- `trace_process_dlopen.sh`
  - 放到样机执行。
  - 使用 `strace` 跟踪特定进程在触发条件功能时打开的 `.so`。
- `scan_dlopen_plugin_evidence.py`
  - 在编译机对 rootfs 执行。
  - 扫描 `dlopen/dlsym` 导入、ELF 内嵌 `.so` 字符串、配置引用和插件目录。
- `merge_dependency_evidence.py`
  - 在编译机执行。
  - 合并 A 脚本静态报告、插件线索报告和多个样机场景采集目录。

---

## 一、产物侧插件和 dlopen 线索扫描

```bash
python3 scan_dlopen_plugin_evidence.py \
    /home/bba/work/bba/7350_develop/platform/targets/M7350/EU/filesystem \
    --json-report plugin_evidence.json \
    --text-report plugin_evidence.txt
```

重点查看：

- 哪些 ELF 导入 `dlopen/dlmopen/dlsym`；
- 哪些 ELF 内嵌 `libxxx.so` 字符串；
- 哪些配置文件明确引用 `.so`；
- 哪些目录属于 `plugins/modules/providers/engines`。

这些只是“可能动态加载”的证据，不能单独作为 KEEP 或 DELETE 结论。

---

## 二、样机按场景持续采集

将脚本推到样机，例如：

```bash
adb push collect_runtime_dependencies.sh /tmp/
adb shell chmod +x /tmp/collect_runtime_dependencies.sh
```

### 开机稳定态

```bash
adb shell '/tmp/collect_runtime_dependencies.sh --scenario boot --once'
```

### Wi-Fi 打开、手机连接并正常上网

```bash
adb shell '/tmp/collect_runtime_dependencies.sh --scenario wifi_on -i 2 -d 120'
```

在这 120 秒内完成 Wi-Fi 开启、STA 连接、Web 管理等操作。

### USB/RNDIS

```bash
adb shell '/tmp/collect_runtime_dependencies.sh --scenario usb_rndis -i 2 -d 120'
```

### WireGuard

```bash
adb shell '/tmp/collect_runtime_dependencies.sh --scenario wireguard -i 1 -d 180'
```

采集期间必须实际完成连接、跑流、断开和重连。

### OpenVPN

```bash
adb shell '/tmp/collect_runtime_dependencies.sh --scenario openvpn -i 1 -d 180'
```

### FOTA/本地升级

```bash
adb shell '/tmp/collect_runtime_dependencies.sh --scenario upgrade -i 1 -d 300'
```

### 建议覆盖的完整场景

- 冷启动、正常启动、异常重启；
- 蜂窝注册、拨号、断网重拨；
- Wi-Fi AP 开关、连接/断开、多客户端；
- USB/RNDIS 插拔；
- Web 管理、REST/CGI；
- WireGuard、OpenVPN、PPTP/L2TP；
- IPv4、IPv6；
- 短信、电话、SIM 切换、PIN；
- FOTA、本地升级、升级失败回退；
- 恢复出厂、配置导入导出；
- 日志抓取、诊断、崩溃转储；
- SD 卡、NTFS/FUSE、UPnP、DLNA 等可选功能；
- 低电、充电、休眠、唤醒；
- 各类错误路径和超时路径。

采集结束后，将每个场景目录拉回编译机：

```bash
adb pull /tmp/libdep_runtime ./runtime_sessions
```

---

## 三、针对可疑进程做 strace 精确跟踪

先查 PID：

```bash
adb shell 'pidof openvpn'
adb shell 'pidof cmm'
```

跟踪 OpenVPN：

```bash
adb shell '
sh /tmp/trace_process_dlopen.sh \
    --pid "$(pidof openvpn)" \
    --duration 180 \
    -o /tmp/openvpn_dlopen_trace
'
```

在 180 秒内执行连接、重连、切换算法、证书加载等操作。

拉回：

```bash
adb pull /tmp/openvpn_dlopen_trace .
```

`opened_libraries.txt` 是本次条件功能期间访问过的动态库或插件路径。

如果目标程序由命令直接启动：

```bash
sh trace_process_dlopen.sh \
    --duration 120 \
    -o /tmp/test_trace \
    -- /usr/bin/my_program --test
```

---

## 四、合并 A + 插件线索 + 多场景运行证据

假设 A 脚本生成：

```text
dependency_report.json
```

执行：

```bash
python3 merge_dependency_evidence.py \
    /home/bba/work/bba/7350_develop/platform/targets/M7350/EU/filesystem \
    --static-json dependency_report.json \
    --plugin-json plugin_evidence.json \
    --runtime-dir runtime_sessions/boot_20260803_100000_123 \
    --runtime-dir runtime_sessions/wifi_on_20260803_101000_456 \
    --runtime-dir runtime_sessions/wireguard_20260803_103000_789 \
    --runtime-dir openvpn_dlopen_trace \
    --output-prefix final_lib_report
```

输出：

- `final_lib_report.json`
- `final_lib_report.csv`
- `final_lib_report.txt`

## 状态解释

### KEEP_RUNTIME_CONFIRMED

样机至少一个场景实际映射或 `strace` 打开过该库。必须保留。

### KEEP_STATIC_REFERENCED

A 脚本确认从可执行文件静态可达或有符号引用。必须保留。

### REVIEW_DYNAMIC_CANDIDATE

存在 `dlopen`、插件目录、配置文件等动态加载线索，但当前场景尚未命中。

需要继续触发对应功能，不能删除。

### REVIEW_UNSEEN

静态分析、动态线索和当前已覆盖场景均未发现。

这只是“进一步移除验证候选”，不等于已经证明多余。

---

## 五、最终删除闭环

只对 `REVIEW_UNSEEN` 中经过人工确认的库操作，并保留符号链接家族。

建议先改名而不是直接删除：

```bash
mv /usr/lib/libfoo.so.1.2.3 /usr/lib/libfoo.so.1.2.3.disabled
```

然后完成：

1. 冷启动；
2. 全场景功能回归；
3. 错误和恢复流程；
4. 日志检查；
5. 再次运行采集；
6. 对比进程、服务和功能结果。

确认后再从构建系统/package 安装阶段移除，避免只改最终 rootfs 造成版本回归。

## 关键边界

任何有限测试都无法数学意义上证明“未来所有条件下绝不会加载某库”。

工程上的完整闭环是：

```text
静态 NEEDED/符号
+ dlopen/插件配置线索
+ 多场景 /proc/maps
+ 可疑进程 strace
+ 改名/移除后的全功能回归
```

只有完成最后的移除回归，才能把候选库确认为可裁剪项。
