#!/usr/bin/env python3
"""
产物侧 dlopen / 插件 / 配置引用线索扫描器。

它不能证明某个插件一定会运行，但可以补齐 ELF DT_NEEDED 看不到的依赖：
1. ELF 是否导入 dlopen/dlmopen/dlsym；
2. ELF 内嵌的 libxxx.so 字符串和插件路径；
3. init/config/script 中引用的 .so、plugin/module/load 指令；
4. 插件目录中存在但未被 DT_NEEDED 引用的共享库。

用法：
    python3 scan_dlopen_plugin_evidence.py <rootfs> \
        --json-report plugin_evidence.json \
        --text-report plugin_evidence.txt
"""

import argparse
import json
import os
import re
import subprocess
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Set, Tuple

DYNAMIC_LOADER_SYMBOLS = {
    "dlopen",
    "dlmopen",
    "dlsym",
    "dlvsym",
    "dlclose",
}

PLUGIN_KEYWORDS = re.compile(
    r"(?i)\b(plugin|plugins|module|modules|loadmodule|load_module|"
    r"dynamic_module|extension|extensions|driver|backend|provider)\b"
)

SO_PATTERN = re.compile(
    rb"(?:(?:/[-A-Za-z0-9_+.@]+)+/)?"
    rb"(?:lib|mod_)?[-A-Za-z0-9_+.@]+\.so(?:\.[-A-Za-z0-9_+.@]+)*"
)

TEXT_SO_PATTERN = re.compile(
    r"(?:(?:/[-A-Za-z0-9_+.@]+)+/)?"
    r"(?:lib|mod_)?[-A-Za-z0-9_+.@]+\.so(?:\.[-A-Za-z0-9_+.@]+)*"
)

PLUGIN_DIR_NAMES = {
    "plugin",
    "plugins",
    "module",
    "modules",
    "extensions",
    "providers",
    "engines",
}

TEXT_EXTENSIONS = {
    ".conf", ".cfg", ".ini", ".json", ".xml", ".yaml", ".yml",
    ".service", ".sh", ".rc", ".lua", ".py", ".js", ".uci",
}


def is_elf(path: Path) -> bool:
    try:
        with path.open("rb") as f:
            return f.read(4) == b"\x7fELF"
    except OSError:
        return False


def is_probably_text(path: Path) -> bool:
    if path.suffix.lower() in TEXT_EXTENSIONS:
        return True
    try:
        data = path.read_bytes()[:4096]
    except OSError:
        return False
    if not data:
        return True
    if b"\x00" in data:
        return False
    printable = sum(1 for b in data if b in b"\t\n\r" or 32 <= b < 127)
    return printable / len(data) >= 0.85


def run_readelf(args: List[str], path: Path) -> str:
    try:
        result = subprocess.run(
            ["readelf", *args, str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=20,
            check=False,
        )
        # 某些嵌入式 ELF 即使返回非零，stdout 仍有有效结果。
        return result.stdout or ""
    except (OSError, subprocess.SubprocessError):
        return ""


def dynamic_undefined_names(path: Path) -> Set[str]:
    output = run_readelf(["-W", "-s", "-D"], path)
    names: Set[str] = set()
    for line in output.splitlines():
        match = re.match(
            r"^\s*\d+:\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+UND\s+(\S+)",
            line,
        )
        if not match:
            continue
        name = match.group(1).split("@", 1)[0]
        names.add(name)
    return names


def printable_strings(data: bytes, min_len: int = 4) -> Iterable[bytes]:
    current = bytearray()
    for value in data:
        if 32 <= value < 127:
            current.append(value)
        else:
            if len(current) >= min_len:
                yield bytes(current)
            current.clear()
    if len(current) >= min_len:
        yield bytes(current)


def embedded_so_references(path: Path) -> Set[str]:
    refs: Set[str] = set()
    try:
        data = path.read_bytes()
    except OSError:
        return refs

    for raw_string in printable_strings(data):
        for match in SO_PATTERN.finditer(raw_string):
            refs.add(match.group(0).decode("utf-8", errors="replace"))
    return refs


def text_evidence(path: Path) -> Tuple[Set[str], List[str]]:
    so_refs: Set[str] = set()
    keyword_lines: List[str] = []

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return so_refs, keyword_lines

    for line_number, line in enumerate(text.splitlines(), 1):
        found_sos = TEXT_SO_PATTERN.findall(line)
        for ref in found_sos:
            so_refs.add(ref)

        if found_sos or PLUGIN_KEYWORDS.search(line):
            compact = " ".join(line.strip().split())
            if compact:
                keyword_lines.append(f"{line_number}: {compact[:500]}")

    return so_refs, keyword_lines[:200]


def relpath(path: Path, root: Path) -> str:
    try:
        return "/" + str(path.relative_to(root))
    except ValueError:
        return str(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("rootfs")
    parser.add_argument("--json-report", default="plugin_evidence.json")
    parser.add_argument("--text-report", default="plugin_evidence.txt")
    args = parser.parse_args()

    root = Path(args.rootfs).resolve()
    if not root.is_dir():
        raise SystemExit(f"rootfs 不存在: {root}")

    elf_records: List[dict] = []
    text_records: List[dict] = []
    plugin_directories: Dict[str, List[str]] = {}
    library_referrers: Dict[str, Set[str]] = defaultdict(set)
    all_shared_libraries: List[str] = []

    for current_root, dirs, files in os.walk(root):
        current = Path(current_root)

        for dirname in dirs:
            if dirname.lower() in PLUGIN_DIR_NAMES:
                plugin_dir = current / dirname
                members = []
                try:
                    for member in sorted(plugin_dir.iterdir()):
                        if member.is_file() or member.is_symlink():
                            if ".so" in member.name:
                                members.append(relpath(member, root))
                except OSError:
                    pass
                plugin_directories[relpath(plugin_dir, root)] = members

        for filename in files:
            path = current / filename
            virtual_path = relpath(path, root)

            if ".so" in filename and (path.is_file() or path.is_symlink()):
                all_shared_libraries.append(virtual_path)

            if path.is_symlink():
                continue

            if is_elf(path):
                undefined = dynamic_undefined_names(path)
                loader_symbols = sorted(undefined & DYNAMIC_LOADER_SYMBOLS)
                embedded_refs = sorted(embedded_so_references(path))

                if loader_symbols or embedded_refs:
                    elf_records.append({
                        "path": virtual_path,
                        "dynamic_loader_symbols": loader_symbols,
                        "embedded_shared_library_references": embedded_refs,
                    })

                for ref in embedded_refs:
                    library_referrers[os.path.basename(ref)].add(
                        f"elf-string:{virtual_path}"
                    )
                continue

            if is_probably_text(path):
                so_refs, evidence_lines = text_evidence(path)
                if so_refs or evidence_lines:
                    text_records.append({
                        "path": virtual_path,
                        "shared_library_references": sorted(so_refs),
                        "evidence_lines": evidence_lines,
                    })
                for ref in so_refs:
                    library_referrers[os.path.basename(ref)].add(
                        f"text-config:{virtual_path}"
                    )

    for directory, members in plugin_directories.items():
        for member in members:
            library_referrers[os.path.basename(member)].add(
                f"plugin-directory:{directory}"
            )

    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "rootfs": str(root),
        "elf_with_dynamic_loading_evidence_count": len(elf_records),
        "text_files_with_plugin_evidence_count": len(text_records),
        "plugin_directory_count": len(plugin_directories),
        "shared_library_file_count": len(set(all_shared_libraries)),
        "elf_records": sorted(elf_records, key=lambda x: x["path"]),
        "text_records": sorted(text_records, key=lambda x: x["path"]),
        "plugin_directories": dict(sorted(plugin_directories.items())),
        "library_referrers": {
            name: sorted(refs)
            for name, refs in sorted(library_referrers.items())
        },
        "all_shared_libraries": sorted(set(all_shared_libraries)),
    }

    json_path = Path(args.json_report)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    lines = [
        "=" * 80,
        "dlopen / 插件 / 配置引用线索报告",
        "=" * 80,
        f"rootfs: {root}",
        f"导入动态加载函数或内嵌 .so 字符串的 ELF: {len(elf_records)}",
        f"含插件/共享库线索的文本文件: {len(text_records)}",
        f"插件目录: {len(plugin_directories)}",
        f"共享库文件: {len(set(all_shared_libraries))}",
        "",
        "按库汇总的潜在动态引用:",
    ]

    if library_referrers:
        for name, refs in sorted(library_referrers.items()):
            lines.append(f"\n{name}")
            for ref in sorted(refs):
                lines.append(f"  - {ref}")
    else:
        lines.append("  无")

    lines.extend([
        "",
        "说明:",
        "1. elf-string/text-config/plugin-directory 是动态依赖线索，不等于运行时必然加载。",
        "2. 必须结合 collect_runtime_dependencies.sh 和 strace 场景跟踪确认。",
        "3. 未发现线索也不能直接证明可删除，可能存在名称拼接、哈希表或远端下发配置。",
    ])

    text_path = Path(args.text_report)
    text_path.parent.mkdir(parents=True, exist_ok=True)
    text_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"JSON 报告: {json_path.resolve()}")
    print(f"文本报告: {text_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
