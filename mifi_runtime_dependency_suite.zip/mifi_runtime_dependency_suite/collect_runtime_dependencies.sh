#!/bin/sh
#
# 样机运行时动态库依赖持续采集工具
#
# 采集内容：
#   1. /proc/<pid>/exe、cmdline、comm
#   2. /proc/<pid>/maps 中实际映射的 .so、动态加载器和已删除映射
#   3. /proc/<pid>/fd 中指向文件的描述符
#   4. 进程 -> 动态库累计关系
#
# 用法：
#   sh collect_runtime_dependencies.sh --scenario boot --once
#   sh collect_runtime_dependencies.sh --scenario wifi_on --interval 2 --duration 120
#   sh collect_runtime_dependencies.sh --scenario wireguard --interval 1 --duration 180 -o /tmp/libdep
#
# 注意：
#   - 建议以 root 执行，否则可能无法读取其他用户进程的 /proc/<pid>/maps。
#   - “未采集到”只代表测试场景未覆盖，不能直接证明库无用。
#

SCENARIO="manual"
OUT_BASE="/tmp/libdep_runtime"
INTERVAL=5
DURATION=0
ONCE=0

usage() {
    cat <<'EOF'
用法:
  collect_runtime_dependencies.sh [选项]

选项:
  --scenario NAME      场景名称，例如 boot/wifi_on/usb/wg/openvpn/fota
  -o, --output DIR     输出根目录，默认 /tmp/libdep_runtime
  -i, --interval SEC   采样间隔，默认 5 秒
  -d, --duration SEC   持续采集时长；0 表示持续运行，直到 Ctrl-C
  --once               只采集一次
  -h, --help           显示帮助

示例:
  sh collect_runtime_dependencies.sh --scenario boot --once
  sh collect_runtime_dependencies.sh --scenario wireguard -i 1 -d 180
EOF
}

while [ $# -gt 0 ]; do
    case "$1" in
        --scenario)
            SCENARIO="$2"
            shift 2
            ;;
        -o|--output)
            OUT_BASE="$2"
            shift 2
            ;;
        -i|--interval)
            INTERVAL="$2"
            shift 2
            ;;
        -d|--duration)
            DURATION="$2"
            shift 2
            ;;
        --once)
            ONCE=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "未知参数: $1" >&2
            usage
            exit 2
            ;;
    esac
done

case "$INTERVAL" in
    ''|*[!0-9]*)
        echo "错误: interval 必须是非负整数" >&2
        exit 2
        ;;
esac

case "$DURATION" in
    ''|*[!0-9]*)
        echo "错误: duration 必须是非负整数" >&2
        exit 2
        ;;
esac

safe_scenario=$(printf '%s' "$SCENARIO" | tr ' /:' '___' | tr -cd 'A-Za-z0-9_.-')
[ -n "$safe_scenario" ] || safe_scenario="manual"

timestamp=$(date '+%Y%m%d_%H%M%S' 2>/dev/null)
[ -n "$timestamp" ] || timestamp="unknown_time"

SESSION_DIR="${OUT_BASE}/${safe_scenario}_${timestamp}_$$"
mkdir -p "$SESSION_DIR" || exit 1

PROCESSES_TSV="$SESSION_DIR/process_snapshots.tsv"
MAPS_TSV="$SESSION_DIR/map_snapshots.tsv"
FDS_TSV="$SESSION_DIR/fd_snapshots.tsv"
RAW_LIBS="$SESSION_DIR/.libraries.raw"
RAW_EDGES="$SESSION_DIR/.process_library_edges.raw"
RAW_DELETED="$SESSION_DIR/.deleted_mappings.raw"
ERROR_LOG="$SESSION_DIR/errors.log"
META="$SESSION_DIR/meta.txt"

printf 'timestamp\tpid\texe\tcomm\tcmdline\n' > "$PROCESSES_TSV"
printf 'timestamp\tpid\texe\tmapped_path\tdeleted\n' > "$MAPS_TSV"
printf 'timestamp\tpid\texe\tfd\ttarget\n' > "$FDS_TSV"
: > "$RAW_LIBS"
: > "$RAW_EDGES"
: > "$RAW_DELETED"
: > "$ERROR_LOG"

{
    echo "scenario=$SCENARIO"
    echo "session_dir=$SESSION_DIR"
    echo "start_time=$(date '+%Y-%m-%d %H:%M:%S %z' 2>/dev/null)"
    echo "hostname=$(hostname 2>/dev/null)"
    echo "kernel=$(uname -a 2>/dev/null)"
    echo "uid=$(id -u 2>/dev/null)"
    echo "interval_seconds=$INTERVAL"
    echo "duration_seconds=$DURATION"
    echo "once=$ONCE"
} > "$META"

sanitize_tsv() {
    tr '\t\r\n' '   '
}

read_cmdline() {
    pid="$1"
    if [ -r "/proc/$pid/cmdline" ]; then
        tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null | sanitize_tsv
    fi
}

read_exe() {
    pid="$1"
    readlink "/proc/$pid/exe" 2>/dev/null | sanitize_tsv
}

read_comm() {
    pid="$1"
    if [ -r "/proc/$pid/comm" ]; then
        cat "/proc/$pid/comm" 2>/dev/null | sanitize_tsv
    elif [ -r "/proc/$pid/stat" ]; then
        sed -n 's/^[0-9][0-9]* (\(.*\)) .*/\1/p' "/proc/$pid/stat" 2>/dev/null | sanitize_tsv
    fi
}

is_library_mapping() {
    path="$1"
    case "$path" in
        *.so|*.so.*|*/ld-*.so*|*/ld-musl-*.so*|*/ld-uClibc*.so*|*/libc.so|*/libpthread.so|*/libdl.so|*/librt.so|*/libm.so)
            return 0
            ;;
    esac
    return 1
}

collect_one_snapshot() {
    now=$(date '+%Y-%m-%dT%H:%M:%S%z' 2>/dev/null)
    [ -n "$now" ] || now="unknown"

    for proc_dir in /proc/[0-9]*; do
        [ -d "$proc_dir" ] || continue
        pid=${proc_dir#/proc/}

        exe=$(read_exe "$pid")
        comm=$(read_comm "$pid")
        cmdline=$(read_cmdline "$pid")

        [ -n "$exe$comm$cmdline" ] || continue

        printf '%s\t%s\t%s\t%s\t%s\n' \
            "$now" "$pid" "$exe" "$comm" "$cmdline" >> "$PROCESSES_TSV"

        if [ -r "$proc_dir/maps" ]; then
            while IFS= read -r map_line; do
                # pathname 通常从第 6 列开始；保留 "(deleted)" 标记。
                map_path=$(printf '%s\n' "$map_line" | awk '{
                    if (NF < 6) next;
                    p=$6;
                    for (i=7; i<=NF; i++) p=p " " $i;
                    print p
                }')
                [ -n "$map_path" ] || continue

                deleted=0
                clean_path=$map_path
                case "$map_path" in
                    *" (deleted)")
                        deleted=1
                        clean_path=${map_path%" (deleted)"}
                        ;;
                esac

                if is_library_mapping "$clean_path"; then
                    printf '%s\t%s\t%s\t%s\t%s\n' \
                        "$now" "$pid" "$exe" "$clean_path" "$deleted" >> "$MAPS_TSV"
                    printf '%s\n' "$clean_path" >> "$RAW_LIBS"
                    printf '%s\t%s\n' "$exe" "$clean_path" >> "$RAW_EDGES"
                    [ "$deleted" -eq 1 ] && printf '%s\t%s\t%s\n' "$pid" "$exe" "$clean_path" >> "$RAW_DELETED"
                fi
            done < "$proc_dir/maps"
        else
            printf '%s pid=%s maps unreadable\n' "$now" "$pid" >> "$ERROR_LOG"
        fi

        if [ -d "$proc_dir/fd" ]; then
            for fd_path in "$proc_dir"/fd/*; do
                [ -e "$fd_path" ] || [ -L "$fd_path" ] || continue
                fd=${fd_path##*/}
                target=$(readlink "$fd_path" 2>/dev/null | sanitize_tsv)
                [ -n "$target" ] || continue
                case "$target" in
                    /*)
                        printf '%s\t%s\t%s\t%s\t%s\n' \
                            "$now" "$pid" "$exe" "$fd" "$target" >> "$FDS_TSV"
                        ;;
                esac
            done
        fi
    done
}

finish() {
    end_time=$(date '+%Y-%m-%d %H:%M:%S %z' 2>/dev/null)
    echo "end_time=$end_time" >> "$META"

    sort -u "$RAW_LIBS" > "$SESSION_DIR/loaded_libraries.txt"
    sort -u "$RAW_EDGES" > "$SESSION_DIR/process_library_edges.tsv"
    sort -u "$RAW_DELETED" > "$SESSION_DIR/deleted_library_mappings.tsv"

    # 统计场景中观察到的唯一进程可执行路径。
    awk -F '\t' 'NR > 1 && $3 != "" {print $3}' "$PROCESSES_TSV" \
        | sort -u > "$SESSION_DIR/observed_executables.txt"

    {
        echo "scenario=$SCENARIO"
        echo "session_dir=$SESSION_DIR"
        echo "unique_executables=$(wc -l < "$SESSION_DIR/observed_executables.txt" 2>/dev/null)"
        echo "unique_libraries=$(wc -l < "$SESSION_DIR/loaded_libraries.txt" 2>/dev/null)"
        echo "process_library_edges=$(wc -l < "$SESSION_DIR/process_library_edges.tsv" 2>/dev/null)"
        echo "deleted_mappings=$(wc -l < "$SESSION_DIR/deleted_library_mappings.tsv" 2>/dev/null)"
    } > "$SESSION_DIR/summary.txt"

    rm -f "$RAW_LIBS" "$RAW_EDGES" "$RAW_DELETED"

    echo
    echo "采集完成: $SESSION_DIR"
    cat "$SESSION_DIR/summary.txt"
}

trap 'finish; exit 0' INT TERM HUP

start_epoch=$(date +%s 2>/dev/null)
[ -n "$start_epoch" ] || start_epoch=0

while :; do
    collect_one_snapshot

    if [ "$ONCE" -eq 1 ]; then
        break
    fi

    if [ "$DURATION" -gt 0 ] && [ "$start_epoch" -gt 0 ]; then
        now_epoch=$(date +%s 2>/dev/null)
        elapsed=$((now_epoch - start_epoch))
        [ "$elapsed" -ge "$DURATION" ] && break
    fi

    sleep "$INTERVAL"
done

finish
exit 0
