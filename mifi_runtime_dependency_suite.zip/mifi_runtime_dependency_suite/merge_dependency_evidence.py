#!/usr/bin/env python3
"""
合并静态 ELF、dlopen/插件线索和多个样机场景运行时采集结果。

输出分类：
- KEEP_RUNTIME_CONFIRMED：至少一个场景实际映射过该库；
- KEEP_STATIC_REFERENCED：A 脚本确认可执行文件/库静态可达；
- REVIEW_DYNAMIC_CANDIDATE：只有 dlopen/插件/配置线索，尚未运行时命中；
- REVIEW_UNSEEN：三类证据都没有，仅可作为进一步验证候选，不能直接删除。

用法：
  python3 merge_dependency_evidence.py ROOTFS \
      --static-json dependency_report.json \
      --plugin-json plugin_evidence.json \
      --runtime-dir boot_session \
      --runtime-dir wifi_session \
      --runtime-dir wg_session \
      --output-prefix final_lib_report
"""

import argparse
import csv
import json
import os
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple


def is_shared_library_name(name: str) -> bool:
    return name.endswith(".so") or ".so." in name


def enumerate_library_aliases(root: Path) -> Tuple[Dict[str, dict], Dict[str, str]]:
    """
    返回：
      canonical_path -> {canonical_name, paths, aliases, size}
      basename/path -> canonical_path
    """
    records: Dict[str, dict] = {}
    lookup: Dict[str, str] = {}

    for current_root, _, files in os.walk(root):
        current = Path(current_root)
        for filename in files:
            if not is_shared_library_name(filename):
                continue

            path = current / filename
            virtual_path = "/" + str(path.relative_to(root))

            try:
                resolved = path.resolve(strict=True)
            except (OSError, RuntimeError):
                resolved = path

            try:
                canonical_virtual = "/" + str(resolved.relative_to(root))
            except ValueError:
                canonical_virtual = virtual_path

            record = records.setdefault(canonical_virtual, {
                "canonical_path": canonical_virtual,
                "canonical_name": os.path.basename(canonical_virtual),
                "paths": set(),
                "aliases": set(),
                "size_bytes": 0,
            })

            record["paths"].add(virtual_path)
            if path.is_symlink():
                record["aliases"].add(filename)

            try:
                record["size_bytes"] = max(record["size_bytes"], resolved.stat().st_size)
            except OSError:
                pass

            lookup[filename] = canonical_virtual
            lookup[virtual_path] = canonical_virtual
            lookup[canonical_virtual] = canonical_virtual
            lookup[os.path.basename(canonical_virtual)] = canonical_virtual

    return records, lookup


def normalize_observed_path(
    value: str,
    root: Path,
    lookup: Dict[str, str],
) -> Optional[str]:
    value = value.strip()
    if not value:
        return None

    if value.endswith(" (deleted)"):
        value = value[:-10]

    if value in lookup:
        return lookup[value]

    basename = os.path.basename(value)
    if basename in lookup:
        return lookup[basename]

    # 如果传入的是 host rootfs 绝对路径，转成目标路径。
    try:
        path = Path(value)
        if path.is_absolute():
            relative = path.resolve().relative_to(root)
            virtual = "/" + str(relative)
            if virtual in lookup:
                return lookup[virtual]
    except (OSError, ValueError, RuntimeError):
        pass

    return None


def load_json(path: Optional[str]) -> dict:
    if not path:
        return {}
    file_path = Path(path)
    if not file_path.is_file():
        raise FileNotFoundError(path)
    return json.loads(file_path.read_text(encoding="utf-8"))


def static_referenced_libraries(report: dict) -> Dict[str, Set[str]]:
    evidence: Dict[str, Set[str]] = defaultdict(set)

    dep_report = report.get("library_dependency_report", {})
    for name in dep_report.get("reachable_libraries", []):
        evidence[name].add("static:reachable_from_executable")

    for name in dep_report.get("executable_root_libraries", []):
        evidence[name].add("static:direct_executable_needed")

    ref_stats = report.get("library_reference_stats", {})
    for item in ref_stats.get("libraries", []):
        name = item.get("library")
        if not name:
            continue
        for executable in item.get("executables", []):
            evidence[name].add(f"static:executable:{executable}")
        for library in item.get("libraries", []):
            evidence[name].add(f"static:library:{library}")

    return evidence


def plugin_evidence(report: dict) -> Dict[str, Set[str]]:
    evidence: Dict[str, Set[str]] = defaultdict(set)
    for name, refs in report.get("library_referrers", {}).items():
        evidence[name].update(f"dynamic-hint:{ref}" for ref in refs)
    return evidence


def runtime_evidence(
    runtime_dirs: Iterable[str],
    root: Path,
    lookup: Dict[str, str],
) -> Tuple[Dict[str, Set[str]], List[dict]]:
    evidence: Dict[str, Set[str]] = defaultdict(set)
    sessions: List[dict] = []

    for runtime_dir in runtime_dirs:
        session = Path(runtime_dir)
        if not session.is_dir():
            raise FileNotFoundError(runtime_dir)

        meta: Dict[str, str] = {}
        meta_file = session / "meta.txt"
        if meta_file.is_file():
            for line in meta_file.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines():
                if "=" in line:
                    key, value = line.split("=", 1)
                    meta[key] = value

        scenario = meta.get("scenario", session.name)
        loaded_file = session / "loaded_libraries.txt"
        loaded_count = 0

        if loaded_file.is_file():
            for line in loaded_file.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines():
                canonical = normalize_observed_path(line, root, lookup)
                if not canonical:
                    continue
                evidence[canonical].add(f"runtime:{scenario}")
                loaded_count += 1

        # 合并 strace 的 opened_libraries.txt。
        opened_file = session / "opened_libraries.txt"
        if opened_file.is_file():
            for line in opened_file.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines():
                canonical = normalize_observed_path(line, root, lookup)
                if not canonical:
                    continue
                evidence[canonical].add(f"strace:{scenario}")

        sessions.append({
            "directory": str(session.resolve()),
            "scenario": scenario,
            "normalized_runtime_hits": loaded_count,
        })

    return evidence, sessions


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("rootfs")
    parser.add_argument("--static-json")
    parser.add_argument("--plugin-json")
    parser.add_argument(
        "--runtime-dir",
        action="append",
        default=[],
        help="可重复指定多个运行时采集目录",
    )
    parser.add_argument("--output-prefix", default="final_lib_report")
    args = parser.parse_args()

    root = Path(args.rootfs).resolve()
    if not root.is_dir():
        raise SystemExit(f"rootfs 不存在: {root}")

    records, lookup = enumerate_library_aliases(root)
    static_report = load_json(args.static_json)
    plugin_report = load_json(args.plugin_json)

    static_raw = static_referenced_libraries(static_report)
    plugin_raw = plugin_evidence(plugin_report)
    runtime_raw, sessions = runtime_evidence(args.runtime_dir, root, lookup)

    static_by_canonical: Dict[str, Set[str]] = defaultdict(set)
    for name, refs in static_raw.items():
        canonical = normalize_observed_path(name, root, lookup)
        if canonical:
            static_by_canonical[canonical].update(refs)

    plugin_by_canonical: Dict[str, Set[str]] = defaultdict(set)
    for name, refs in plugin_raw.items():
        canonical = normalize_observed_path(name, root, lookup)
        if canonical:
            plugin_by_canonical[canonical].update(refs)

    rows: List[dict] = []
    summary = defaultdict(int)

    for canonical, record in sorted(records.items()):
        runtime_refs = sorted(runtime_raw.get(canonical, set()))
        static_refs = sorted(static_by_canonical.get(canonical, set()))
        dynamic_refs = sorted(plugin_by_canonical.get(canonical, set()))

        if runtime_refs:
            status = "KEEP_RUNTIME_CONFIRMED"
            reason = "至少一个样机场景实际映射或 strace 打开该库"
        elif static_refs:
            status = "KEEP_STATIC_REFERENCED"
            reason = "静态 ELF 依赖图确认可达/被引用"
        elif dynamic_refs:
            status = "REVIEW_DYNAMIC_CANDIDATE"
            reason = "存在 dlopen、插件目录或配置引用线索，但运行时尚未命中"
        else:
            status = "REVIEW_UNSEEN"
            reason = "当前静态、动态线索和已覆盖场景均未观察到"

        summary[status] += 1

        rows.append({
            "library": record["canonical_name"],
            "canonical_path": canonical,
            "size_bytes": record["size_bytes"],
            "all_paths": sorted(record["paths"]),
            "aliases": sorted(record["aliases"]),
            "status": status,
            "reason": reason,
            "runtime_evidence": runtime_refs,
            "static_evidence": static_refs,
            "dynamic_hint_evidence": dynamic_refs,
        })

    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "rootfs": str(root),
        "static_json": args.static_json,
        "plugin_json": args.plugin_json,
        "runtime_sessions": sessions,
        "summary": dict(sorted(summary.items())),
        "critical_warning": (
            "REVIEW_UNSEEN 不能直接等同于可删除。只有覆盖全部产品功能、异常流程、"
            "升级/恢复/诊断场景并完成移除回归后，才能升级为删除候选。"
        ),
        "libraries": rows,
    }

    prefix = Path(args.output_prefix)
    json_path = prefix.with_suffix(".json")
    csv_path = prefix.with_suffix(".csv")
    txt_path = prefix.with_suffix(".txt")

    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "library",
                "canonical_path",
                "size_bytes",
                "status",
                "reason",
                "runtime_evidence",
                "static_evidence",
                "dynamic_hint_evidence",
                "all_paths",
                "aliases",
            ],
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({
                **row,
                "runtime_evidence": " | ".join(row["runtime_evidence"]),
                "static_evidence": " | ".join(row["static_evidence"]),
                "dynamic_hint_evidence": " | ".join(
                    row["dynamic_hint_evidence"]
                ),
                "all_paths": " | ".join(row["all_paths"]),
                "aliases": " | ".join(row["aliases"]),
            })

    lines = [
        "=" * 80,
        "动态库多证据合并报告",
        "=" * 80,
        f"rootfs: {root}",
        f"运行时场景数: {len(sessions)}",
    ]
    for key, value in sorted(summary.items()):
        lines.append(f"{key}: {value}")

    for status in (
        "REVIEW_DYNAMIC_CANDIDATE",
        "REVIEW_UNSEEN",
    ):
        lines.extend(["", status, "-" * len(status)])
        selected = [row for row in rows if row["status"] == status]
        if not selected:
            lines.append("无")
        for row in selected:
            lines.append(
                f"{row['canonical_path']} "
                f"({row['size_bytes']} bytes) - {row['reason']}"
            )
            for evidence_item in row["dynamic_hint_evidence"]:
                lines.append(f"  dynamic: {evidence_item}")

    lines.extend([
        "",
        "重要说明:",
        report["critical_warning"],
    ])
    txt_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"JSON: {json_path.resolve()}")
    print(f"CSV : {csv_path.resolve()}")
    print(f"文本: {txt_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
