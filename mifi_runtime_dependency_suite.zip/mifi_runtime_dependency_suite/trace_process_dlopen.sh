#!/bin/sh
#
# 使用 strace 捕获运行时 dlopen/插件装载相关文件访问。
#
# 原理：
#   dlopen() 最终会触发 open/openat/stat/readlink/mmap 等系统调用。
#   在执行目标条件功能期间跟踪这些调用，可以捕获延迟加载的 .so。
#
# 用法：
#   sh trace_process_dlopen.sh --pid 1234 --duration 120 -o /tmp/wg_trace
#   sh trace_process_dlopen.sh --pid 1234,5678 --duration 180 -o /tmp/vpn_trace
#   sh trace_process_dlopen.sh --duration 120 -o /tmp/app_trace -- /usr/bin/app arg1
#
# 注意：
#   - 样机必须安装 strace。
#   - 对已运行进程建议 root 执行。
#   - 跟踪期间必须实际触发相关条件功能。
#

PID_LIST=""
DURATION=120
OUT_DIR="/tmp/dlopen_trace_$(date '+%Y%m%d_%H%M%S' 2>/dev/null)_$$"
MODE="attach"

usage() {
    cat <<'EOF'
用法:
  trace_process_dlopen.sh --pid PID[,PID...] [--duration SEC] [-o DIR]
  trace_process_dlopen.sh [--duration SEC] [-o DIR] -- COMMAND [ARGS...]

示例:
  sh trace_process_dlopen.sh --pid "$(pidof openvpn)" --duration 180 -o /tmp/openvpn_trace
  sh trace_process_dlopen.sh --pid 123,456 --duration 120 -o /tmp/multi_trace
  sh trace_process_dlopen.sh -o /tmp/test -- /usr/bin/my_app --test

输出:
  strace.raw.log             完整系统调用
  library_accesses.log       包含 .so/插件关键词的访问
  opened_libraries.txt       提取出的库路径/库名
EOF
}

while [ $# -gt 0 ]; do
    case "$1" in
        --pid)
            PID_LIST="$2"
            shift 2
            ;;
        --duration)
            DURATION="$2"
            shift 2
            ;;
        -o|--output)
            OUT_DIR="$2"
            shift 2
            ;;
        --)
            MODE="command"
            shift
            break
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "未知参数: $1" >&2
            usage
            exit 2
            ;;
    esac
done

if ! command -v strace >/dev/null 2>&1; then
    echo "错误: 样机没有 strace，无法进行系统调用级 dlopen 跟踪。" >&2
    exit 3
fi

case "$DURATION" in
    ''|*[!0-9]*)
        echo "错误: duration 必须是整数" >&2
        exit 2
        ;;
esac

mkdir -p "$OUT_DIR" || exit 1
RAW="$OUT_DIR/strace.raw.log"
FILTERED="$OUT_DIR/library_accesses.log"
LIBS="$OUT_DIR/opened_libraries.txt"
META="$OUT_DIR/meta.txt"

TRACE_SET="open,openat,openat2,access,faccessat,stat,lstat,newfstatat,readlink,readlinkat,mmap,mmap2,execve"

{
    echo "start_time=$(date '+%Y-%m-%d %H:%M:%S %z' 2>/dev/null)"
    echo "mode=$MODE"
    echo "pids=$PID_LIST"
    echo "duration_seconds=$DURATION"
    echo "output_dir=$OUT_DIR"
} > "$META"

run_with_limit() {
    if command -v timeout >/dev/null 2>&1; then
        timeout "$DURATION" "$@"
        return $?
    fi

    "$@" &
    child=$!
    (
        sleep "$DURATION"
        kill -INT "$child" 2>/dev/null
        sleep 1
        kill -TERM "$child" 2>/dev/null
    ) &
    watcher=$!
    wait "$child"
    rc=$?
    kill "$watcher" 2>/dev/null
    wait "$watcher" 2>/dev/null
    return "$rc"
}

if [ "$MODE" = "command" ]; then
    if [ $# -eq 0 ]; then
        echo "错误: -- 后没有指定命令" >&2
        exit 2
    fi
    run_with_limit strace -f -tt -T -s 1024 \
        -e trace="$TRACE_SET" \
        -o "$RAW" \
        "$@"
else
    if [ -z "$PID_LIST" ]; then
        echo "错误: attach 模式必须指定 --pid" >&2
        exit 2
    fi

    old_ifs=$IFS
    IFS=', '
    ATTACH_ARGS=""
    for pid in $PID_LIST; do
        case "$pid" in
            ''|*[!0-9]*)
                echo "忽略无效 PID: $pid" >&2
                ;;
            *)
                if [ -d "/proc/$pid" ]; then
                    ATTACH_ARGS="$ATTACH_ARGS -p $pid"
                else
                    echo "PID 不存在: $pid" >&2
                fi
                ;;
        esac
    done
    IFS=$old_ifs

    if [ -z "$ATTACH_ARGS" ]; then
        echo "错误: 没有可跟踪的有效 PID" >&2
        exit 2
    fi

    # shellcheck disable=SC2086
    run_with_limit strace -f -tt -T -s 1024 \
        -e trace="$TRACE_SET" \
        -o "$RAW" \
        $ATTACH_ARGS
fi

# 捕获 .so、插件、模块目录和动态加载器相关访问。
grep -Ei \
    '\.so([.0-9A-Za-z_-]*)?|/plugins?/|/modules?/|dlopen|ld-musl|ld-uClibc|ld-linux' \
    "$RAW" > "$FILTERED" 2>/dev/null || :

# 从引号参数中提取可能的库路径/库名。
awk '
{
    line=$0
    while (match(line, /"[^"]+"/)) {
        s=substr(line, RSTART+1, RLENGTH-2)
        if (s ~ /\.so([.0-9A-Za-z_-]*)?$/ ||
            s ~ /\/plugins?\// ||
            s ~ /\/modules?\// ||
            s ~ /ld-musl/ ||
            s ~ /ld-uClibc/ ||
            s ~ /ld-linux/) {
            print s
        }
        line=substr(line, RSTART+RLENGTH)
    }
}' "$FILTERED" | sort -u > "$LIBS"

{
    echo "end_time=$(date '+%Y-%m-%d %H:%M:%S %z' 2>/dev/null)"
    echo "raw_lines=$(wc -l < "$RAW" 2>/dev/null)"
    echo "library_access_lines=$(wc -l < "$FILTERED" 2>/dev/null)"
    echo "unique_library_paths=$(wc -l < "$LIBS" 2>/dev/null)"
} >> "$META"

echo "跟踪完成: $OUT_DIR"
echo "动态库访问列表: $LIBS"
